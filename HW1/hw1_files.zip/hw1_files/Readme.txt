To view the sample output file:
--------------------------------------------------------------

Dowload the output file. If you copy/paste it, some characters
may not be copied correctly.
Open using gedit or emacs on a Linux machine.


